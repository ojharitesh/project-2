1. Get the code:
   ```bash
   git clone https://github.com/GatorEducator/gatorverse-project-submissions-fusionforce.git
   cd gatorverse-project-submissions-fusionforce/skill-bridge
   ``` 